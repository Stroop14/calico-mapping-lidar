Silver King Mine, Calico: 2019 LiDAR scan (works with no internet).
1. Unzip this folder, and keep all of its files together.
2. Double-click "START HERE - open this.html". It opens in your web browser (Chrome, Edge, Safari or Firefox).
3. If it does not open or the 3-D tunnel stays blank, see "IF IT WONT OPEN.txt".
